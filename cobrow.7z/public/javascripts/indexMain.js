window.onload = function () {
    if(dataObtained.validationFailed){
        window.alert("Incorrect password!");
    }
}; 