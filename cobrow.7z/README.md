# Co-Browsing
<h3>Author: <strong>Supernova</strong></h3>
The IDE for collaborative development, automatic versioning and contributions management.  

It contains the initial function for developer as code-sharing.